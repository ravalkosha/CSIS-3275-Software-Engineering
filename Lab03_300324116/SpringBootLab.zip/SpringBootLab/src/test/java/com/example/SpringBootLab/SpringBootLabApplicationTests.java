package com.example.SpringBootLab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
